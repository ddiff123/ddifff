<?php 

namespace Member;

class Download extends \Home {

	use \Helper\Download;

	protected
		$download;

	function beforeRoute($f3) {
		parent::beforeRoute($f3);
		if ( $this->me->isAdmin()) $f3->reroute('/home/admin/download/');
		$this->download = new \Download;
	}

	function All($f3) {
		$download = $this->download->find(array('active=1'));
		$f3->set('download',$download);
		$f3->set('subcontent','member/downloads.html');
	}
	
	function Id($f3) {
		$download = $this->loadDown();
		$f3->set('download',$download);
		$f3->set('subcontent','member/downloads.html');
	}
}
