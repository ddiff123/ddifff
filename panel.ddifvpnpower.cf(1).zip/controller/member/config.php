<?php 

namespace Member;

class Config extends \Home {

	use \Helper\Server;

	protected
		$seller;

	function loadSeller() {
		$f3 = \Base::instance();
		$seller = $this->seller;
		if ($f3->exists('PARAMS.id')) {
			$id = $f3->get('PARAMS.id');
			$seller->load(array('id=? AND type=2',$id));
			$seller->reroute('/home/member/wallet');
		}
		return $seller;
	}
	
		function Id($f3) {
		$seller = $this->loadSeller();
		$f3->set('seller',$seller);
		$f3->set('subcontent','member/wallet.html');
	}

	
	function Wallet($f3) {

		$f3->set('subcontent','member/wallet.html');
	}
	
	function Deposit2($f3) {
	    $f3 = \Base::instance();
	    $post 	= $f3->get('POST');	    
        $dsn = $f3->DB_SET;
        $db_user = $f3->DB_USER;
        $db_pass = $f3->DB_PASS;
        $db = new \DB\SQL($dsn,$db_user,$db_pass);
        $user = new \DB\SQL\Mapper($db,'user');
		if (($this->me->saldo)<$post['deposit']){
			$this->flash('Your Balance is not enough, Contact Administrator');
		   	$f3->reroute('/home/member/wallet');
		}
		if (($this->me->username)==$post['username']){
			$this->flash('You cannot transfer to yourself');
			$f3->reroute('/home/member/wallet');
		}		
        if ($user->dry()) {
	    	$user->load(array('username=?',$post['username']));
		    if ( ! $user->dry()) {
			   $user->saldo = ($user->saldo + $post['deposit']);
	    	   $user->save();
	    	   $this->me->saldo = $this->me->saldo-$post['deposit'];
	    	   $this->me->save();
	    	   $this->flash('Wallet transfer done','success');
	    	   $f3->reroute('/home/member/wallet');
	    	    }
    			$this->flash('User not exist!!');
            	$f3->reroute('/home/member/wallet');
           }
	
	}

	function Coin($f3) {

		$f3->set('subcontent','member/coin.html');
	}
	
	function Changer($f3) {
	 $f3 = \Base::instance();
	 $post = $f3->get('POST');
	 $coin = $post['coin'] * 5;	    
        $dsn = $f3->DB_SET;
        $db_user = $f3->DB_USER;
        $db_pass = $f3->DB_PASS;
        $db = new \DB\SQL($dsn,$db_user,$db_pass);
        $user = new \DB\SQL\Mapper($db,'user');
	 if (($this->me->coin)<$coin){
	 $this->flash('Your coin is not enough for change, please earn more');
	 $f3->reroute('/home/member/coin');
	 }		
	 $this->me->saldo = ($this->me->saldo + $post['coin']);
	 $this->me->save();
	 $this->me->coin = $this->me->coin-$coin;
	 $this->me->save();
	 $this->flash('Coin change done','success');
	 $f3->reroute('/home/member/coin');
	 }
	
}