<?php 

namespace Member;

class Package extends \Home {

	use \Helper\Package;

	protected
		$package;

	function beforeRoute($f3) {
		parent::beforeRoute($f3);
		if ( $this->me->isAdmin()) $f3->reroute('/home/admin/package/');
		$this->package = new \Package;
	}

	function All($f3) {
		$package = $this->package->find(array('active=1'));
		$f3->set('package',$package);
		$f3->set('subcontent','member/packages.html');
	}

	function Id($f3) {
		$package = $this->loadPackage();
		$f3->set('package',$package);
		$f3->set('subcontent','member/package.html');
	}

	function Buy($f3) {
	 $package = $this->loadPackage();
	 $post = $f3->get('POST');
        $dsn = $f3->DB_SET;
        $db_user = $f3->DB_USER;
        $db_pass = $f3->DB_PASS;
        $db = new \DB\SQL($dsn,$db_user,$db_pass);
        $user = new \DB\SQL\Mapper($db,'user');

        if (($this->me->saldo)<$package->price){
		$this->flash('Your wallet balance is not enough, contact admin to reload');
		$f3->reroute('/home/member/package');
		}
        if (($this->me->username)==$post['username']){
$this->flash('This package is not available for your account. Please contact admin for further clarification');
			$f3->reroute('/home/member/package');
		}
        if ($user->dry()) {
	    	$user->load(array('username=?',$post['username']));
		    if ( ! $user->dry()) {	
		    $this->flash('Username already being used by another agent');
			$f3->reroute('/home/member/package'); }
        $db->begin();
	 $user->username = $post['username'];
        $user->password = \Bcrypt::instance()->hash($post['password']);
	 $user->firstname = $post['firstname'];
        $user->lastname = $post['lastname'];
        $user->email = $post['email'];
        $user->type = $package->type;
        $user->saldo = $package->harga;
        $user->upline = $this->me->username;
        $user->active = 1;
        $user->save();
	 $this->me->saldo = $this->me->saldo-$package->price;
	 $this->me->save();
	 $this->me->saldo = $this->me->saldo+$package->profit;
	 $this->me->save();
		$db->commit();
        $this->flash('Congratulation. You already register one agent. ','success');
		$f3->reroute('/home/member/package');
		}
        
	}
	
}