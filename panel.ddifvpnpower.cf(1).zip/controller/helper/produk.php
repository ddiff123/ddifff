<?php

namespace Helper;

trait Produk {

	function loadProd() {
		$f3 = \Base::instance();
		$produk = $this->produk;
		if ($f3->exists('PARAMS.id',$id)) {
			if ($this->me->isAdmin()) {
				$produk->id($id);
				$produk->reroute('/home/admin/produk');
			} else {
				$produk->load(array('id=? AND active=1',$id));
				$produk->reroute('/home/member/produk');
			}
		}
		return $produk;
	}

}