<?php

namespace Helper;

trait Download {

	function loadDown() {
		$f3 = \Base::instance();
		$download = $this->download;
		if ($f3->exists('PARAMS.id',$id)) {
			if ($this->me->isAdmin()) {
				$download->id($id);
				$download->reroute('/home/admin/download');
			} else {
				$download->load(array('id=? AND active=1',$id));
				$download->reroute('/home/member/download');
			}
		}
		return $download;
	}

}