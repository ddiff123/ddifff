<?php 

namespace Admin;

class Buyer extends \Home {

	use \Helper\Buyer;
	
	protected
		$buyer;

	function beforeRoute($f3) {
		parent::beforeRoute($f3);
		$this->buyer = new \Buyer;
	}

	function All($f3) {
	$buyers = $this->buyer->find();
	$f3->set('buyers',$buyers);
	$f3->set('subcontent','admin/buyers.html');
	}

	function loadBuyer() {
		$f3 = \Base::instance();
		$buyer = $this->buyer;
		if ($f3->exists('PARAMS.id')) {
			$id = $f3->get('PARAMS.id');
			$buyer->load(array('id=?',$id));
			$buyer->reroute('/home/admin/buyer');
		}
		return $buyer;
	}

	function Id($f3) {
		$buyer = $this->loadBuyer();
		$f3->set('seller',$buyer);
		$f3->set('subcontent','admin/buyer.html');
	}
		function Resit($f3) {
		$buyer = $this->loadBuyer();
		$f3->set('buyer',$buyer);
		$f3->set('subcontent','admin/resit.html');
	}
	
		function Delivered($f3) {
		$buyer = $this->loadBuyer();
		if ($buyer->dry()) {
		$buyer->load(array('username=?',$f3->get('POST.username')));
			if ( ! $buyer->dry()) {
				$this->flash('Buyer already register');
				$f3->reroute('/home/admin/buyer');
			}
		}

		$buyer->status = $f3->get('POST.status');
		$buyer->user = $f3->get('POST.user');
		$buyer->active = 0;
		$buyer->save();
		$this->flash('Item already Delivered!! ','success');
		$f3->reroute('/home/admin/buyer/');
	}
	

}