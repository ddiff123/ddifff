<?php 

namespace Admin;

class Download extends \Home {

	use \Helper\Download;
	
	protected
		$download;

	function beforeRoute($f3) {
		parent::beforeRoute($f3);
		if ( ! $this->me->isAdmin()) $f3->reroute('/logout');
		$this->download = new \Download;
	}

	function All($f3) {
		$download = $this->download->find();
		$f3->set('download',$download);
		$f3->set('subcontent','admin/downloads.html');
	}

	function loadDown() {
		$f3 = \Base::instance();
		$download = $this->download;
		if ($f3->exists('PARAMS.id')) {
			$id = $f3->get('PARAMS.id');
			$download->load(array('id=? AND active=1',$id));
			$download->reroute('/home/admin/download');
		}
		return $download;
	}

	function loadDown2() {
		$f3 = \Base::instance();
		$download = $this->download;
		if ($f3->exists('PARAMS.id')) {
			$id = $f3->get('PARAMS.id');
			$download->load(array('id=? AND active=0',$id));
			$download->reroute('/home/admin/download');
		}
		return $download;
	}
	
	function Id($f3) {
		$download = $this->loadDown();
		$down = $this->download;
		$f3->set('download',$down);
		$f3->set('subcontent','admin/download.html');
	}

	function Set($f3) {
		$download = $this->loadDown();
		if ($download->dry()) {
			$download->load(array('servername=?',$f3->get('POST.servername')));
			if ( ! $download->dry()) {
				$this->flash('Config already register');
				$f3->reroute('/home/admin/download/add');
			}
		}
		$download->copyFrom('POST');
		$download->active = 1;
		$download->save();
		$this->flash('Saved Success','success');
		$f3->reroute('/home/admin/download/'.$download->id);
	}

	function Locked($f3) {
	    $download = $this->loadDown();
		$download->active = 0;
		$download->save();
		$this->flash('Config was Locked','success');
		$f3->reroute('/home/admin/download/');
		
	}
	
	function Unlocked($f3) {
	    $download = $this->loadDown2();
		$download->active = 1;
		$download->save();
		$this->flash('Config was Unlocked','success');
		$f3->reroute('/home/admin/download/');
		
	}
	
	function Delete($f3) {
		$download = $this->loadDown();
		$download->erase();
		$this->flash('Config deleted successfully','success');
		$f3->reroute('/home/admin/download/');
	}
	
	function Edit($f3) {
		$download = $this->loadDown();
		$f3->set('download',$download);
		$f3->set('subcontent','admin/download.html');
	}
	

}