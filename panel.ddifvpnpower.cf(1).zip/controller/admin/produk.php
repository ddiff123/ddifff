<?php 

namespace Admin;

class Produk extends \Home {

	use \Helper\Produk;
	
	protected
		$produk;

	function beforeRoute($f3) {
		parent::beforeRoute($f3);
		if ( ! $this->me->isAdmin()) $f3->reroute('/logout');
		$this->produk = new \Produk;
	}

	function All($f3) {
		$produk = $this->produk->find();
		$f3->set('produk',$produk);
		$f3->set('subcontent','admin/produks.html');
	}

	function loadProduk() {
		$f3 = \Base::instance();
		$produk = $this->produk;
		if ($f3->exists('PARAMS.id')) {
			$id = $f3->get('PARAMS.id');
			$produk->load(array('id=? AND active=1',$id));
			$produk->reroute('/home/admin/produk');
		}
		return $produk;
	}

	function loadProd2() {
		$f3 = \Base::instance();
		$produk = $this->produk;
		if ($f3->exists('PARAMS.id')) {
			$id = $f3->get('PARAMS.id');
			$produk->load(array('id=? AND active=0',$id));
			$produk->reroute('/home/admin/produk');
		}
		return $produk;
	}
	
	function Id($f3) {
		$produk = $this->loadProd();
		$prod = $this->produk;
		$f3->set('produk',$prod);
		$f3->set('subcontent','admin/produk.html');
	}

	function Set($f3) {
		$produk = $this->loadProd();
		if ($produk->dry()) {
			$produk->load(array('produk=?',$f3->get('POST.produk')));
			if ( ! $produk->dry()) {
				$this->flash('Product already register');
				$f3->reroute('/home/admin/produk/add');
			}
		}
		$produk->copyFrom('POST');
		$produk->active = 1;
		$produk->save();
		$this->flash('Saved Success','success');
		$f3->reroute('/home/admin/produk/'.$produk->id);
	}

	function Locked($f3) {
	    $produk = $this->loadProd();
		$produk->active = 0;
		$produk->save();
		$this->flash('Product was Locked','success');
		$f3->reroute('/home/admin/produk/');
		
	}
	
	function Unlocked($f3) {
	    $produk = $this->loadProd();
		$produk->active = 1;
		$produk->save();
		$this->flash('Product was Unlocked','success');
		$f3->reroute('/home/admin/produk/');
		
	}
	
	function Delete($f3) {
		$produk = $this->loadProd();
		$produk->erase();
		$this->flash('Product deleted successfully','success');
		$f3->reroute('/home/admin/produk/');
	}
	
	function Edit($f3) {
		$produk = $this->loadProd();
		$f3->set('produk',$produk);
		$f3->set('subcontent','admin/eproduk.html');
	}
	
		function Edited($f3) {
	    	$f3 = \Base::instance();
	    	$post 	= $f3->get('POST');	    
        	$dsn = $f3->DB_SET;
        	$db_user = $f3->DB_USER;
        	$db_pass = $f3->DB_PASS;
        	$db = new \DB\SQL($dsn,$db_user,$db_pass);
        	$produk = new \DB\SQL\Mapper($db,'produk');

        if ($produk->dry()) {
	    	$produk->load(array('produk=?',$post['produk']));
		    if ( ! $user->dry()) {
			   $user->saldo = ($user->saldo + $post['deposit']);
	    	   $user->save();
	    	   $this->me->saldo = $this->me->saldo-$post['deposit'];
	    	   $this->me->save();
	    	   $this->flash('Wallet transfer done','success');
	    	   $f3->reroute('/home/member/wallet');
	    	    }
    			$this->flash('User not exist!!');
            	$f3->reroute('/home/member/wallet');
           }
	
	}

	

}