<?php

class Register extends Controller {

	function In($f3) {
		if ($f3->exists('SESSION.id')) $f3->reroute('/home');
		$f3->set('content','register.html');
	}

	function Post($f3) {
        $f3 = Base::instance();
        $dsn = $f3->DB_SET;
        $db_user = $f3->DB_USER;
        $db_pass = $f3->DB_PASS;
        $db = new \DB\SQL($dsn,$db_user,$db_pass);
        $user = new \DB\SQL\Mapper($db,'user');
        if ($user->dry()) {
			$user->load(array('username=?',$f3->get('POST.username')));
			if ( ! $user->dry()) {
				$this->flash('User Already registered');
				$f3->reroute('/register');
			}
        $db->begin();
        $post = $f3->get('POST');
		$user->username = $post['username'];
        $user->password = \Bcrypt::instance()->hash($post['password']);
		$user->firstname = $post['firstname'];
        $user->lastname = $post['lastname'];
        $user->email = $post['email'];
        $user->type = 3;
        $user->saldo = 0;
        $user->active = 1;
        $user->save();
		$db->commit();
        $this->flash('Congratulation. Your account have been registered. Please login','success');
		$f3->reroute('/');
		}
        
	}

	
}