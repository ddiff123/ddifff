SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+08:00";

CREATE TABLE `buyer` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `product` varchar(255) NOT NULL,
  `price` int(11) NOT NULL,
  `validity` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `user` varchar(255) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

CREATE TABLE `download` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `servername` varchar(255) NOT NULL,
  `digi` varchar(255) NOT NULL,
  `maxis` varchar(255) NOT NULL,
  `umobile` varchar(255) NOT NULL,
  `celcom` varchar(255) NOT NULL,
  `unifi` varchar(255) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

CREATE TABLE `package` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `package` varchar(255) NOT NULL,
  `type` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `harga` int(11) NOT NULL,
  `profit` int(11) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

CREATE TABLE `produk` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `produk` varchar(255) NOT NULL,
  `validity` varchar(255) NOT NULL,
  `price` int(11) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

CREATE TABLE `server` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `servername` varchar(255) NOT NULL,
  `server_owner` varchar(255) NOT NULL,
  `country` varchar(30) NOT NULL,
  `host` varchar(255) NOT NULL,
  `openssh` varchar(255) NOT NULL,
  `dropbear` varchar(255) NOT NULL,
  `stunnel` varchar(255) NOT NULL,
  `proxy` varchar(255) NOT NULL,
  `openvpn_port` varchar(255) NOT NULL,
  `openvpn_link` varchar(255) NOT NULL,
  `limitacc` varchar(255) NOT NULL,
  `torrent` varchar(20) NOT NULL,
  `price` int(10) NOT NULL,
  `root_pass` varchar(500) NOT NULL,
  `hari` varchar(128) NOT NULL,
  `coin` int(11) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

CREATE TABLE `user` (
   `id` int(10) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(60) NOT NULL,
  `upline` varchar(255) NOT NULL,
  `saldo` int(10) NOT NULL DEFAULT '0',
  `coin` int(11) NOT NULL,
  `type` tinyint(1) NOT NULL DEFAULT '2',
  `active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;
